# 📱 Quiz de Fases - PWA

Este projeto é um **Quiz com múltiplas fases** feito em **HTML, CSS e JavaScript**, adaptado como **PWA (Progressive Web App)**.

✅ Funciona offline  
✅ Pode ser instalado como app no celular  
✅ Simples de hospedar no **GitHub Pages**

## 📝 Como acessar seu Quiz

1. Faça o deploy no GitHub Pages.
2. Acesse pela URL:  
`https://seu-usuario.github.io/quiz-pwa/`

## 📂 Estrutura do Projeto

/ (raiz)
├── index.html
├── manifest.json
├── service-worker.js
└── README.md

## ⚙️ Tecnologias

- HTML5 + CSS3 + JavaScript  
- Manifest & Service Worker (PWA)  
- GitHub Pages (para hospedagem gratuita)

## 📦 Como publicar no GitHub Pages

1. Crie um repositório no GitHub (ex: quiz-pwa).
2. Envie os arquivos (index.html, manifest.json, service-worker.js, README.md).
3. Vá em Settings > Pages.
4. Selecione a branch main e a pasta / (root).
5. Pronto! Seu quiz estará online como PWA.
